var indexSectionsWithContent =
{
  0: "fgmoprsw",
  1: "fgpr",
  2: "m",
  3: "fgmoprsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции"
};

